//
//  ViewController.swift
//  Exam1_55011212173
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBOutlet weak var SubjectTextField: UITextField!
    @IBOutlet weak var MidtermTextField: UITextField!
    @IBOutlet weak var MidTextField: UITextField!
    @IBOutlet weak var ScoreTextField: UITextField!
    @IBOutlet weak var ScTextField: UITextField!
    @IBOutlet weak var FinalTextField: UITextField!
    @IBOutlet weak var FiTextField: UITextField!

    @IBOutlet weak var show: UITextView!
    
    @IBOutlet weak var TableView: UITableView!
    
    @IBAction func calculate(sender: AnyObject) {
        
        var nameSubject = String(SubjectTextField.text as NSString)
        var mid = Int((MidTextField.text as NSString).integerValue)
        var md = Double((MidTextField.text as NSString).doubleValue)
        var sc = Double((ScTextField.text as NSString).doubleValue)
        var score = Int((ScoreTextField.text as NSString).integerValue)
        
        var fi = Double((FiTextField.text as NSString).doubleValue)
        var final = Int((FinalTextField.text as NSString).integerValue)
        
       
        var gread:String = " "
        var total1 = mid + score + final
        var total = md + sc + fi
        
       
            
            if (total < 44) {
                gread = "F"
            }
            else if (total < 50) {
                gread = "D"
            }
            else if (total < 56) {
                gread = "D+"
            }
            else if (total < 62) {
                gread = "C"
            }
            else if (total < 68) {
                gread = "C+"
            }
            else if (total < 74) {
                gread = "B"
            }
            else if (total < 80) {
                gread = "B+"
            }
            else {
                gread = "A"
            }
          
            show.text = "\(nameSubject) เกรด \(gread)"
        }
    
    
    
    
    
}

